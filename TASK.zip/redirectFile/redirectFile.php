<?php
$config = file_get_contents('config.json');
$config = json_decode($config, true);

?>
<html class="no-js" lang="">

<head>
    <meta charset="utf-8">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1"><!-- Place favicon.ico in the root directory -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
          integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>


<body>
</body>
</html>
<script>
    /*window.onunload = function() {
      /!*  var win = window.opener;
        if (!win.closed) {
            win.checkCheat();
        }*!/
    };*/

</script>
<!--header( "refresh:". $config['delay'] .";url=".$config['redirect'] );-->
